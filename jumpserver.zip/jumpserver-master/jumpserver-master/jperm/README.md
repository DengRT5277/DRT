# Jperm App

---

### 模块 ansible_api 

> 使用说明

+ 依赖rpm安装包： ansible、 sshpass
+ 依赖pip安装包： passlib
+ 关于ansible配置： 需要启用配置文件(/etc/ansible/ansible.cfg)的 host_key_checking = False

